<header>
	
	<div class="nav_toggle" onclick="toggle_class();">
		
		<span class="toggle_icon"></span>
		
	</div>
	
	<div onclick="remove_class()">
	
	<div class="main_nav">
		
		<h2>Pescado Seafood Restaurant</h2>
		
		<ul class="default_links">
			
			<li><a href="index.php">HOME</a></li>
			<!-- <li><a href="menu.php">MENU</a></li> -->
			<!-- <li><a href="reservation.php">RESREVATION</a></li> -->
			
			<li><a href="gallery.php">GALLERY</a></li>
			<!-- <li><a href="basket.php">ORDER</a></li> -->
			<li><a href="../resto/login-form-20/login.php">LOGIN</a></li>
			<li><a href="../resto/signup-form-19/register.php">SIGN UP</a></li>
		</ul>
		
		<p class="clear"></p>
		
	</div>
	
	<p class="clear"></p>
	
	</div>
	
</header>

<div class="responive_nav">
	
	<div class="nav_section_img">
		
		<div class="nav_section_div">
			
			<h3>Unique Restaurant</h3>
			
		</div>
		
	</div>
	
	<div class="nav_section">
		
		<ul>
			
			<li><a href="index.php"><span class="home">Home</span></a></li>
			<li><a href="menu.php"><span class="menu">Menu</span></a></li>
			<li><a href="reservation.php"><span class="reserve">Book Table</span></a></li>
			<li><a href="gallery.php"><span class="gallery">Gallery</span></a></li>
			<li><a href="basket.php"><span class="order">Order</span></a></li>
			
		</ul>
		
	</div>
	
</div>