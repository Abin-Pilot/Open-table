<div class="sidebar-wrapper">
           <!--  <div class="logo">
                <a href="index.php" class="simple-text">
                    Unique Restaurant
                </a>
            </div> -->

            <!-- <ul class="nav">
                <li>
                    <a href="food_list.php">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="food_add.php">
                        <i class="pe-7s-note"></i>
                        <p>Add Food</p>
                    </a>
                </li>
				
                <li>
                    <a href="orders.php">
                        <i class="pe-7s-note2"></i>
                        <p>Orders</p>
                    </a>
                </li>
				<li>
                    <a href="reservations.php">
                        <i class="pe-7s-note2"></i>
                        <p>Table reservations</p>
                    </a>
                </li> -->
				<!--<li>
                    <a href="#">
                        <i class="pe-7s-news-paper"></i>
                        <p>Gallery</p>
                    </a>
                </li>-->
                
           <!--  </ul> -->
    	</div>
    </div>