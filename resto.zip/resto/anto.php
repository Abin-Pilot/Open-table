<?php
include("includes/header.php");
include("includes/sidenav.php");
include("includes/connection.php");
$count=0;
$classid=$_SESSION["classid"];
?>






<div id="page-wrapper" style="height: auto;" >

  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <h1 class="page-header"><b>STUDENT APPLICATION SUMMARY
        <b></h1>
      </div>
      <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
  </div>







  <ul class="nav nav-tabs">

    <li class="active"><a data-toggle="tab"  href="#menu1">Approved</a></li>
    <li><a data-toggle="tab" href="#menu2">Pending</a></li>
    <li><a data-toggle="tab" href="#menu3">Rejected</a></li>
    <li><a data-toggle="tab" href="#menu4">Resubmitted</a></li>
  </ul>

  <div class="tab-content">
    <div id="menu1" class="tab-pane fade in active">
      <h4>Approved Lists</h4>
      <div class="table-responsive">
<table   class="table table-hover table-bordered" >
 <tr>
  <th style="text-align: center; text-transform: uppercase;">serial no</th>

  <th style="text-align: center;">APPLICATION ID</th>
  <th style="text-align: center;">ADMISSION NUMBER</th>
  <th style="text-align: center;">NAME</th>
  <!-- <th style="text-align: center;">SEMESTER</th> -->
  <th style="text-align: center;">SUBJECT</th>
  <th style="text-align: center;">APPLIED DATE</th>
  <th style="text-align: center;">EXPECTED DATE</th>
  <!-- <th style="text-align: center;">STATUS</th> -->
  <th style="text-align: center;">VIEW</th>
  <th style="text-align: center;">ATTACHMENT</th>
  <!-- <th style="text-align: center;">REJECTED BY</th>
  <th style="text-align: center;">REJECTED ON</th>
  <th style="text-align: center;">COMMENT</th> -->



</tr>




<?php

$resul=mysql_query("select sa.*,sd.name from student_application sa inner join staff_advisor s on sa.class_id=s.classid inner join stud_details sd on sd.admissionno=sa.admissionno where fid='$fid' and sa.status in (5)");
$serial_no = 0;
while($dat=mysql_fetch_array($resul))
{
  $serial_no++;
  $app_id=$dat["app_id"];
  $admissionno=$dat["admissionno"];
  $name=$dat["name"];
  $admissionno=$dat["admissionno"];
  $subject=$dat["subject"];
  $appdate=$dat["applieddate"];
  $expdate=$dat["expected_date"];
  $status=$dat["status"];
  $view=$dat["view"];
  $attachment=$dat["attachment"];




  ?>
  <tr align="center">

    <td align="center"><?php  echo $serial_no;?></td>
    <td align="center"><?php  echo $app_id;?></td>
    <td align="center"><?php  echo $admissionno;?></td>
    <td align="center"><?php  echo $name;?></td>
    <td align="center"><?php  echo $subject;?></td>
    <td align="center"><?php  echo $appdate;?></td>
    <td align="center"><?php  echo $expdate;?></td>
    <!-- <td align="center"><?php  echo $status;?></td> -->
    <td align="center"><?php  echo $view;?></td>
    <td align="center"><?php  echo $attachment;?></td>


    <!-- <td align="center"> <a href="">Approve</a> </td>
    <td align="center"> <a href="">Reject</a> </td -->
  </tr>
   <?php } ?>
</table>
    </div>
  </div>



  <div id="menu2" class="tab-pane fade">
   <h4>Pending Lists</h4>
   <div class="table-responsive">
<table   class="table table-hover table-bordered" >
 <tr>
  <th style="text-align: center; text-transform: uppercase;">serial no</th>

  <th style="text-align: center;">APPLICATION ID</th>
  <th style="text-align: center;">ADMISSION NUMBER</th>
  <th style="text-align: center;">NAME</th>
  <!-- <th style="text-align: center;">SEMESTER</th> -->
  <th style="text-align: center;">SUBJECT</th>
  <th style="text-align: center;">APPLIED DATE</th>
  <th style="text-align: center;">EXPECTED DATE</th>
  <!-- <th style="text-align: center;">STATUS</th> -->
  <th style="text-align: center;">VIEW</th>
  <th style="text-align: center;">ATTACHMENT</th>
  <th style="text-align: center;">APPROVE</th>
  <th style="text-align: center;">REJECT</th>





</tr>




<?php

$resul=mysql_query("select sa.*,sd.name from student_application sa inner join staff_advisor s on sa.class_id=s.classid inner join stud_details sd on sd.admissionno=sa.admissionno where fid='$fid' and sa.status in (1,2,3,4)");
$serial_no = 0;
while($dat=mysql_fetch_array($resul))
{
  $serial_no++;
  $app_id=$dat["app_id"];
  $admissionno=$dat["admissionno"];
  $name=$dat["name"];
  $admissionno=$dat["admissionno"];
  $subject=$dat["subject"];
  $appdate=$dat["applieddate"];
  $expdate=$dat["expected_date"];
  $status=$dat["status"];
  $view=$dat["view"];
  $attachment=$dat["attachment"];




  ?>
  <tr align="center">

    <td align="center"><?php  echo $serial_no;?></td>
    <td align="center"><?php  echo $app_id;?></td>
    <td align="center"><?php  echo $admissionno;?></td>
    <td align="center"><?php  echo $name;?></td>
    <td align="center"><?php  echo $subject;?></td>
    <td align="center"><?php  echo $appdate;?></td>
    <td align="center"><?php  echo $expdate;?></td>
    <!-- <td align="center"><?php  echo $status;?></td> -->
    <td align="center"><?php  echo $view;?></td>
    <td align="center"><?php  echo $attachment;?></td>
    <!-- <td align="center"> <a href="">Approve</a> </td>
    <td align="center"> <a href="">Reject</a> </td> -->
    <!--  -->



    <td align="center" ><a href="" class="" data-toggle="modal" data-target="#myModal">Approve</a></td>

    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">comment</h4>
          </div>
          <div class="modal-body">
            <textarea  style="min-height: 100px;" class="form-control"  name="comment" placeholder="type here" required maxlength="190"></textarea>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">Submit</button>
          </div>
        </div>
      </div>
    </div>


    <td align="center" ><a href="" class="" data-toggle="modal" data-target="#myModal1">Reject</a></td>

    <!-- Modal -->


    <div class="modal fade" id="myModal1" role="dialog">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Comment</h4>
          </div>
          <div class="modal-body">
            <textarea  style="min-height: 100px;" class="form-control"  name="comment" placeholder="Type the reason for rejection" required maxlength="190"></textarea>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">Submit</button>
          </div>
        </div>
      </div>
    </div>
  </tr>
   <?php } ?>
</table>
  </div>
  </div>


  <div id="menu3" class="tab-pane fade">
  <h4>Rejected Lists</h4>
  <div class="table-responsive">
<table   class="table table-hover table-bordered" >
 <tr>
  <th style="text-align: center; text-transform: uppercase;">serial no</th>

  <th style="text-align: center;">APPLICATION ID</th>
  <th style="text-align: center;">ADMISSION NUMBER</th>
  <th style="text-align: center;">NAME</th>
  <!-- <th style="text-align: center;">SEMESTER</th> -->
  <th style="text-align: center;">SUBJECT</th>
  <th style="text-align: center;">APPLIED DATE</th>
  <th style="text-align: center;">EXPECTED DATE</th>
  <th style="text-align: center;">VIEW</th>
  <th style="text-align: center;">ATTACHMENT</th>
  <th style="text-align: center;">REJECTED BY</th>
  <th style="text-align: center;">REJECTED ON</th>
  <th style="text-align: center;">COMMENT</th>



</tr>




<?php

$resul=mysql_query("select sa.*,sd.name from student_application sa inner join staff_advisor s on sa.class_id=s.classid inner join stud_details sd on sd.admissionno=sa.admissionno where fid='$fid' and sa.status in (6,7,8,9)");
$serial_no = 0;
while($dat=mysql_fetch_array($resul))
{
  $serial_no++;
  $app_id=$dat["app_id"];
  $admissionno=$dat["admissionno"];
  $name=$dat["name"];
  $admissionno=$dat["admissionno"];
  $subject=$dat["subject"];
  $appdate=$dat["applieddate"];
  $expdate=$dat["expected_date"];
  $status=$dat["status"];
  $view=$dat["view"];
  $attachment=$dat["attachment"];

  if($status==6)
        {
          $Rejected_date=$dat["sa_approved_date"];
          $Rejected_by='Staff Advisor';
          $comment=$dat["sa_comment"];
        }
        else if($status==7)
        {
          $Rejected_date=$dat["hod_approved_date"];
          $Rejected_by='HOD';
          $comment=$dat["hod_comment"];
        }
        else if($status==8)
        {
          $Rejected_date=$dat["principal_approved_date"];
          $Rejected_by='Principal';
          $comment=$dat["principal_comment"];
        }
        else
        {
          $Rejected_date=$dat["office_approved_date"];
          $Rejected_by='Office';
          $comment=$dat["office_comment"];
        }


  ?>
  <tr align="center">

    <td align="center"><?php  echo $serial_no;?></td>
    <td align="center"><?php  echo $app_id;?></td>
    <td align="center"><?php  echo $admissionno;?></td>
    <td align="center"><?php  echo $name;?></td>
    <td align="center"><?php  echo $subject;?></td>
    <td align="center"><?php  echo $appdate;?></td>
    <td align="center"><?php  echo $expdate;?></td>
    <td align="center"><?php  echo $view;?></td>
    <td align="center"><?php  echo $attachment;?></td>
    <td align="center"><?php  echo $Rejected_by;?></td>
    <td align="center"><?php  echo $Rejected_date;?></td>
    <td align="center"><?php  echo $comment;?></td>

    <!-- <td align="center"> <a href="">Approve</a> </td>
    <td align="center"> <a href="">Reject</a> </td -->
  </tr>
   <?php } ?>
</table>
  </div>
  </div>

  <div id="menu4" class="tab-pane fade">
  <h4>Resubmitted Lists</h4>
  <div class="table-responsive">
<table   class="table table-hover table-bordered" >
 <tr>
  <th style="text-align: center; text-transform: uppercase;">serial no</th>

  <th style="text-align: center;">APPLICATION ID</th>
  <th style="text-align: center;">ADMISSION NUMBER</th>
  <th style="text-align: center;">NAME</th>
  <!-- <th style="text-align: center;">SEMESTER</th> -->
  <th style="text-align: center;">SUBJECT</th>
  <th style="text-align: center;">APPLIED DATE</th>
  <th style="text-align: center;">EXPECTED DATE</th>
  <!-- <th style="text-align: center;">STATUS</th> -->
  <th style="text-align: center;">VIEW</th>
  <th style="text-align: center;">ATTACHMENT</th>
  <th style="text-align: center;">APPROVE</th>
  <th style="text-align: center;">REJECT</th>




</tr>




<?php

$resul=mysql_query("select sa.*,sd.name from student_application sa inner join staff_advisor s on sa.class_id=s.classid inner join stud_details sd on sd.admissionno=sa.admissionno where fid='$fid' and sa.status in (10)");
$serial_no = 0;
while($dat=mysql_fetch_array($resul))
{
  $serial_no++;
  $app_id=$dat["app_id"];
  $admissionno=$dat["admissionno"];
  $name=$dat["name"];
  $admissionno=$dat["admissionno"];
  $subject=$dat["subject"];
  $appdate=$dat["applieddate"];
  $expdate=$dat["expected_date"];
  $status=$dat["status"];
  $view=$dat["view"];
  $attachment=$dat["attachment"];




  ?>
  <tr align="center">

    <td align="center"><?php  echo $serial_no;?></td>
    <td align="center"><?php  echo $app_id;?></td>
    <td align="center"><?php  echo $admissionno;?></td>
    <td align="center"><?php  echo $name;?></td>
    <td align="center"><?php  echo $subject;?></td>
    <td align="center"><?php  echo $appdate;?></td>
    <td align="center"><?php  echo $expdate;?></td>
    <!-- <td align="center"><?php  echo $status;?></td> -->
    <td align="center"><?php  echo $view;?></td>
    <td align="center"><?php  echo $attachment;?></td>
    <!-- <td align="center"> <a href="">Approve</a> </td>
    <td align="center"> <a href="">Reject</a> </td> -->



    <td align="center" ><a href="" class="" data-toggle="modal" data-target="#myModal2">Approve</a></td>

    <!-- Modal -->
    <div class="modal fade" id="myModal2" role="dialog">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">comment</h4>
          </div>
          <div class="modal-body">
            <textarea  style="min-height: 100px;" class="form-control"  name="comment" placeholder="type here" required maxlength="190"></textarea>




              <div class="container mt-3">
              <h2>Forward to</h2>
              <form action="/action_page.php">
                <div class="custom-control custom-radio">
                  <!-- <input type="radio" class="custom-control-input" id="customRadio" name="example1">
                  <label class="custom-control-label" for="customRadio">HOD</label>  -->
                </div>
                <input type="radio" id="defaultRadio" name="example2">
                <label for="defaultRadio">HOD</label>
                <br>
                <!-- <button type="submit" class="btn btn-primary">Submit</button> -->
              </form>
            </div>



          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">Submit</button>
          </div>
        </div>
      </div>
    </div>


    <td align="center" ><a href="" class="" data-toggle="modal" data-target="#myModal3">Reject</a></td>

    <!-- Modal -->


    <div class="modal fade" id="myModal3" role="dialog">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Comment</h4>
          </div>
          <div class="modal-body">
            <textarea  style="min-height: 100px;" class="form-control"  name="comment" placeholder="Type the reason for rejection" required maxlength="190"></textarea>




          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">Submit</button>
          </div>
        </div>
      </div>
    </div>
  </tr>
   <?php } ?>
</table>
  </div>
  </div>















<?php

include("includes/footer.php");
?